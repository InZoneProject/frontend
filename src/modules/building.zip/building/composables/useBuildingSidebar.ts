import { computed } from 'vue'
import type { BuildingViewSidebarEmits } from '@/modules/building/interfaces/building-view-sidebar-emits.interface'
import type { BuildingViewSidebarProperties } from '@/modules/building/interfaces/building-view-sidebar-properties.interface'
import type { CurrentBuildingEmployee } from '@/modules/building/interfaces/current-building-employee.interface'
import type { FloorItem } from '@/modules/building/interfaces/floor-item.interface'

export const useBuildingSidebar = (
    properties: BuildingViewSidebarProperties,
    emit: BuildingViewSidebarEmits
) => {
    const sidePanelTabs = computed(() => {
        const tabs = [{ id: 'floors', label: properties.translations.floors.title || 'Поверхи' }]
        if (!properties.isEmployeesHidden) {
            tabs.push({ id: 'employees', label: properties.translations.employees.title || 'Співробітники' })
        }
        return tabs
    })

    const toolbarClasses = computed(() => ({
        'is-add-floor-hidden': properties.isFloorsCollapsed || (!properties.isEmployeesHidden && properties.sidePanelTab === 'employees')
    }))

    const getFloorRowClasses = (floor: FloorItem) => ({
        'is-selected': properties.selectedFloorId === floor.floor_id,
        'is-dragging': properties.draggedFloorId === floor.floor_id
    })

    const selectSidePanelTab = (tab: string | number) => {
        if (tab !== 'floors' && tab !== 'employees') return
        if (tab === 'employees' && properties.isEmployeesHidden) return
        emit('selectSidePanelTab', tab)
    }

    const selectFloor = (floorId: number) => emit('update:selectedFloorId', floorId)
    const updateFloorsSearch = (value: string) => emit('update:floorsSearch', value)
    const updateBuildingEmployeesSearch = (value: string) => emit('update:buildingEmployeesSearch', value)
    const updateFloorsOffset = (value: number) => emit('update:floorsOffset', value)
    const updateBuildingEmployeesOffset = (value: number) => emit('update:buildingEmployeesOffset', value)
    const toggleFloorsCollapsed = () => emit('toggleFloorsCollapsed')
    const openCreateFloorModal = () => emit('openCreateFloorModal')
    const openEditFloorModal = (floor: FloorItem) => emit('openEditFloorModal', floor)
    const openDeleteFloorModal = (floorId: number) => emit('openDeleteFloorModal', floorId)
    const startFloorDrag = (floor: FloorItem, event: DragEvent) => emit('startFloorDrag', floor, event)
    const moveFloorDrag = (floor: FloorItem) => emit('moveFloorDrag', floor)
    const finishFloorDrag = () => emit('finishFloorDrag')
    const cancelFloorDrag = () => emit('cancelFloorDrag')
    const openBuildingEmployeeInfo = (employee: CurrentBuildingEmployee) => emit('openBuildingEmployeeInfo', employee)
    const openExpelModal = (employee: CurrentBuildingEmployee) => emit('openExpelModal', employee)

    return {
        sidePanelTabs,
        toolbarClasses,
        getFloorRowClasses,
        selectSidePanelTab,
        selectFloor,
        updateFloorsSearch,
        updateBuildingEmployeesSearch,
        updateFloorsOffset,
        updateBuildingEmployeesOffset,
        toggleFloorsCollapsed,
        openCreateFloorModal,
        openEditFloorModal,
        openDeleteFloorModal,
        startFloorDrag,
        moveFloorDrag,
        finishFloorDrag,
        cancelFloorDrag,
        openBuildingEmployeeInfo,
        openExpelModal
    }
}
