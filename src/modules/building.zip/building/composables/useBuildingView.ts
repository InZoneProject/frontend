import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useDateFormatter } from '@/composables/useDateFormatter'
import { useLanguageSwitcher } from '@/composables/useLanguageSwitcher'
import { useAuthStore } from '@/stores/auth.store'
import { buildingEditDeleteRepository } from '@/repositories/building-edit-delete.repository'
import { positionsRepository } from '@/repositories/positions.repository'
import { participantsControlRepository } from '@/repositories/participants-control.repository'
import { buildingRepository } from '@/modules/building/repositories/building.repository'
import { buildingLocationsSocketService } from '@/modules/building/services/building-locations-socket.service'
import { buildingEmployeePhotoService } from '@/modules/building/services/building-employee-photo.service'
import { BUILDING_MAP_PREVIEW_CONSTANTS } from '@/modules/building/constants/building-map-preview.constants'
import { createBuildingViewMapState } from '@/modules/building/services/building-view-map.service'
import { createBuildingViewZoneState } from '@/modules/building/services/building-view-zone.service'
import { createBuildingViewDoorState } from '@/modules/building/services/building-view-door.service'
import { LIST } from '@/constants/list.constants'
import type { OrganizationMemberProfile } from '@/interfaces/organization-member-profile.interface'
import type { OrganizationPositionItem } from '@/modules/organization/interfaces/organization-position-item.interface'
import type { BuildingInfo } from '@/modules/building/interfaces/building-info.interface'
import type { DoorMapItem } from '@/modules/building/interfaces/door-map-item.interface'
import type { EmployeeLocation } from '@/modules/building/interfaces/employee-location.interface'
import type { EmployeeLocationSocketPayload } from '@/modules/building/interfaces/employee-location-socket-payload.interface'
import type { CurrentBuildingEmployee } from '@/modules/building/interfaces/current-building-employee.interface'
import type { FloorItem } from '@/modules/building/interfaces/floor-item.interface'
import type { ViewportBounds } from '@/modules/building/interfaces/viewport-bounds.interface'
import type { ZoneMapItem } from '@/modules/building/interfaces/zone-map-item.interface'
import type { OrganizationListParams } from '@/interfaces/organization-list-params.interface'
import { BuildingMapMode } from '@/modules/building/enums/building-map-mode.enum'

export const useBuildingView = () => {
    const route = useRoute()
    const router = useRouter()
    const authStore = useAuthStore()
    const { formatDate } = useDateFormatter()
    const { translations } = useLanguageSwitcher()

    const buildingId = computed(() => Number(route.params.buildingId))
    const defaultBuilding: BuildingInfo = { building_id: 0, organization_id: 0, title: '', address: null, created_at: '' }
    const building = ref<BuildingInfo>(defaultBuilding)
    const buildingCreatedAt = ref('')
    const floors = ref<FloorItem[]>([])
    const draggedFloorId = ref(0)
    const dragOverFloorId = ref(0)
    const zones = ref<ZoneMapItem[]>([])
    const transitionValidationZones = ref<ZoneMapItem[]>([])
    const transitionValidationDoors = ref<DoorMapItem[]>([])
    const deletableZoneIds = ref<number[]>([])
    const deletableDoorIds = ref<number[]>([])
    const doors = ref<DoorMapItem[]>([])
    const currentBuildingEmployees = ref<CurrentBuildingEmployee[]>([])
    const sidePanelTab = ref<'floors' | 'employees'>(route.query.tab === 'employees' ? 'employees' : 'floors')
    const selectedFloorId = ref(0)
    const floorsSearch = ref('')
    const buildingEmployeesSearch = ref('')
    const floorsOffset = ref(0)
    const buildingEmployeesOffset = ref(0)
    const floorsLimit = ref(LIST.DEFAULT_LIMIT)
    const buildingEmployeesLimit = ref(LIST.DEFAULT_LIMIT)
    const floorsTotal = ref(0)
    const buildingEmployeesTotal = ref(0)
    const viewport = ref<ViewportBounds>({ x: 0, y: 0, width: 80, height: 45 })
    const isInitiallyFloorsCollapsed = route.query.floors === 'collapsed'
    const isFloorsCollapsed = ref(isInitiallyFloorsCollapsed)
    const isBuildingMapExpanded = ref(isInitiallyFloorsCollapsed)
    const buildingMapMode = ref<BuildingMapMode>(route.query.mode === BuildingMapMode.VIEW ? BuildingMapMode.VIEW : BuildingMapMode.EDIT)
    const isLoadingBuilding = ref(false)
    const isLoadingFloors = ref(false)
    const isLoadingBuildingEmployees = ref(false)
    const isExpelModalOpen = ref(false)
    const isExpellingMember = ref(false)
    const employeeToExpel = ref<CurrentBuildingEmployee | null>(null)
    const selectedMemberProfile = ref<OrganizationMemberProfile | null>(null)
    const isMemberInfoModalOpen = ref(false)
    const isLoadingMemberProfile = ref(false)
    const isMemberPositionsModalOpen = ref(false)
    const isPositionsEditMode = ref(false)
    const isLoadingMemberPositions = ref(false)
    const isLoadingAvailablePositions = ref(false)
    const assignedMemberPositions = ref<OrganizationPositionItem[]>([])
    const availableMemberPositions = ref<OrganizationPositionItem[]>([])
    const assignedPositionsSearchValue = ref('')
    const availablePositionsSearchValue = ref('')
    const assignedPositionsOffset = ref(0)
    const availablePositionsOffset = ref(0)
    const assignedPositionsTotal = ref(0)
    const availablePositionsTotal = ref(0)
    const memberPositionsLimit = LIST.DEFAULT_LIMIT
    const isPositionUpsertModalOpen = ref(false)
    const positionModalMode = ref<'create' | 'edit'>('create')
    const positionToEditId = ref<number | null>(null)
    const positionRoleValue = ref('')
    const positionDescriptionValue = ref('')
    const initialPositionRoleValue = ref('')
    const initialPositionDescriptionValue = ref('')
    const isPositionSubmitting = ref(false)
    const isDeletePositionModalOpen = ref(false)
    const positionToDeleteId = ref<number | null>(null)
    const isDeletingPosition = ref(false)

    const isBuildingModalOpen = ref(false)
    const buildingTitleValue = ref('')
    const buildingAddressValue = ref('')
    const initialBuildingTitleValue = ref('')
    const initialBuildingAddressValue = ref('')
    const isBuildingSubmitting = ref(false)

    const isFloorModalOpen = ref(false)
    const floorModalMode = ref<'create' | 'edit'>('create')
    const floorNameValue = ref('')
    const floorEditingId = ref(0)
    const initialFloorNameValue = ref('')
    const isFloorSubmitting = ref(false)

    const isDeleteBuildingModalOpen = ref(false)
    const floorToDeleteId = ref(0)
    const isDeletingFloor = ref(false)

    let floorsSearchDebounce: number | null = null
    let floorsCollapseTimeout: number | null = null
    let readersSearchDebounce: number | null = null
    let buildingEmployeesSearchDebounce: number | null = null
    let assignedPositionsSearchDebounce: number | null = null
    let availablePositionsSearchDebounce: number | null = null
    let unsubscribeLocationListener: (() => void) | null = null
    let floorsRequestId = 0
    let buildingEmployeesRequestId = 0
    const getFloorsStateFromQuery = () => route.query.floors === 'collapsed'

    const runBackground = (request: Promise<unknown>) => {
        request.catch(() => undefined)
    }

    const syncFloorsStateToRoute = async (collapsed: boolean) => {
        const nextValue = collapsed ? 'collapsed' : 'expanded'
        if (route.query.floors === nextValue) return
        await router.replace({
            name: 'Building',
            params: { buildingId: String(buildingId.value) },
            query: { ...route.query, floors: nextValue }
        })
    }

    const syncSelectedFloorToRoute = async (floorId: number) => {
        if (floorId === 0 || route.query.floor === String(floorId)) return
        await router.replace({
            name: 'Building',
            params: { buildingId: String(buildingId.value) },
            query: { ...route.query, floor: String(floorId) }
        })
    }

    const syncSidePanelTabToRoute = async (tab: 'floors' | 'employees') => {
        if (route.query.tab === tab) return
        await router.replace({
            name: 'Building',
            params: { buildingId: String(buildingId.value) },
            query: { ...route.query, tab }
        })
    }

    const syncMapModeToRoute = async (mode: BuildingMapMode) => {
        if (route.query.mode === mode) return
        await router.replace({
            name: 'Building',
            params: { buildingId: String(buildingId.value) },
            query: { ...route.query, mode }
        })
    }

    const applyFloorsStateImmediately = (collapsed: boolean) => {
        if (floorsCollapseTimeout !== null) {
            window.clearTimeout(floorsCollapseTimeout)
            floorsCollapseTimeout = null
        }
        isFloorsCollapsed.value = collapsed
        isBuildingMapExpanded.value = collapsed
    }

    const { isLoadingMap, fetchMap, scheduleMapSync, updateViewport } = createBuildingViewMapState({
        selectedFloorId,
        viewport,
        zones,
        transitionValidationZones,
        transitionValidationDoors,
        deletableZoneIds,
        deletableDoorIds,
        doors
    })

    const {
        isZoneCreateModalOpen,
        zoneTitleValue,
        zoneIsTransitionBetweenFloors,
        zoneCanCreateTransition,
        zoneCreateErrorMessage,
        isZoneSubmitting,
        isEditingZone,
        accessRulesZoneId,
        accessRulesZoneTitle,
        zoneToDeleteId,
        isDeletingZone,
        canSubmitZone,
        openZoneAccessRulesModal,
        closeZoneAccessRulesModal,
        commitZoneGeometry,
        shiftZone,
        updateZoneTitle,
        updateZonePhoto,
        addZone,
        closeZoneCreateModal,
        submitZone,
        openDeleteZoneModal,
        closeDeleteZoneModal,
        confirmDeleteZone
    } = createBuildingViewZoneState({
        buildingId,
        selectedFloorId,
        zones,
        transitionValidationZones,
        doors,
        transitionValidationDoors,
        deletableZoneIds,
        deletableDoorIds,
        zoneCreateDefaultErrorMessage: computed(() => translations.value.organizationAdmin.buildingPage.zoneForm.defaultError),
        zoneOverlapErrorMessage: computed(() => translations.value.organizationAdmin.buildingPage.zoneForm.overlapError),
        zoneNoIntersectionErrorMessage: computed(() => translations.value.organizationAdmin.buildingPage.zoneForm.noIntersectionError),
        zoneDoorSpaceErrorMessage: computed(() => translations.value.organizationAdmin.buildingPage.zoneForm.doorSpaceError),
        scheduleMapSync
    })

    const {
        doorToDelete,
        isDeletingDoor,
        readerDoorId,
        selectedDoorReader,
        availableReaders,
        readersSearch,
        readersOffset,
        readersLimit,
        readersTotal,
        isLoadingReaders,
        generatedReaderToken,
        isReaderModalOpen,
        readerModalMode,
        readerNameValue,
        isReaderSubmitting,
        readerToDelete,
        isDeletingReader,
        readerToRegenerate,
        isRegeneratingReaderToken,
        readerTokenCopySuccessMessage,
        canSubmitReader,
        addDoor,
        openDeleteDoorModal,
        closeDeleteDoorModal,
        confirmDeleteDoor,
        fetchDoorReaders,
        openDoorReaderModal,
        closeDoorReaderModal,
        assignReaderToDoor,
        unassignReaderFromDoor,
        openRegenerateReaderTokenModal,
        closeRegenerateReaderTokenModal,
        confirmRegenerateReaderToken,
        openDeleteReaderModal,
        closeDeleteReaderModal,
        confirmDeleteReader,
        openCreateReaderModal,
        openEditReaderModal,
        closeReaderModal,
        submitReader,
        copyGeneratedReaderToken
    } = createBuildingViewDoorState({
        doors,
        transitionValidationDoors,
        deletableDoorIds,
        copySuccessMessage: computed(() => translations.value.organizationAdmin.buildingPage.doorReader.copySuccess)
    })

    const formattedCreatedAt = computed(() => buildingCreatedAt.value ? formatDate(buildingCreatedAt.value) : '-')
    const canSubmitBuilding = computed(() => {
        const title = buildingTitleValue.value.trim()
        const address = buildingAddressValue.value.trim()
        return title.length > 0 && (title !== initialBuildingTitleValue.value || address !== initialBuildingAddressValue.value)
    })

    const canSubmitFloor = computed(() => {
        const value = floorNameValue.value.trim()
        if (value.length === 0) return false
        if (floorModalMode.value === 'create') return true
        return value !== initialFloorNameValue.value
    })
    const canSubmitPositionForm = computed(() => {
        const role = positionRoleValue.value.trim()
        const description = positionDescriptionValue.value.trim()
        if (role.length === 0) return false
        if (positionModalMode.value === 'create') return true
        return role !== initialPositionRoleValue.value || description !== initialPositionDescriptionValue.value
    })
    const canDeleteFloor = computed(() => floorsTotal.value > 1)
    const displayedFloors = computed(() => {
        if (draggedFloorId.value === 0 || dragOverFloorId.value === 0 || draggedFloorId.value === dragOverFloorId.value) {
            return floors.value
        }
        const next = [...floors.value]
        const fromIndex = next.findIndex((floor) => floor.floor_id === draggedFloorId.value)
        const toIndex = next.findIndex((floor) => floor.floor_id === dragOverFloorId.value)
        if (fromIndex < 0 || toIndex < 0) return floors.value
        const [draggedFloor] = next.splice(fromIndex, 1)
        next.splice(toIndex, 0, draggedFloor)
        return next.map((floor, index) => ({ ...floor, floor_number: index + 1 }))
    })
    const areSidebarTabsHidden = computed(() =>
        buildingMapMode.value === BuildingMapMode.EDIT
        || isEditingZone.value
        || isZoneCreateModalOpen.value
    )

    const fetchBuilding = async () => {
        isLoadingBuilding.value = true
        try {
            const response = await buildingEditDeleteRepository.getBuildingInfo(buildingId.value)
            building.value = response.data
            buildingCreatedAt.value = response.data.created_at
        } catch {
            building.value = defaultBuilding
            buildingCreatedAt.value = ''
        } finally {
            isLoadingBuilding.value = false
        }
    }

    const fetchFloors = async () => {
        if (isLoadingFloors.value) return
        const requestId = ++floorsRequestId
        isLoadingFloors.value = true
        try {
            const params: OrganizationListParams = {
                search: floorsSearch.value,
                offset: floorsOffset.value,
                limit: floorsLimit.value
            }
            const response = await buildingRepository.getFloors(buildingId.value, params)
            if (requestId !== floorsRequestId) return
            floors.value = floorsOffset.value === 0 ? response.data.items : [...floors.value, ...response.data.items]
            floorsTotal.value = response.data.total
            if (selectedFloorId.value === 0 && response.data.items.length > 0) {
                const floorFromRoute = Number(route.query.floor)
                const selectedFloor = response.data.items.find((item) => item.floor_id === floorFromRoute)
                selectedFloorId.value = selectedFloor?.floor_id || response.data.items[0].floor_id
                runBackground(fetchMap())
            }
        } catch {
            if (requestId !== floorsRequestId) return
            if (floorsOffset.value === 0) {
                floors.value = []
                floorsTotal.value = 0
            }
        } finally {
            if (requestId === floorsRequestId) isLoadingFloors.value = false
        }
    }

    const reloadFloors = async () => {
        if (floorsOffset.value !== 0) {
            floorsOffset.value = 0
            return
        }
        await fetchFloors()
    }

    const fetchCurrentBuildingEmployees = async () => {
        if (isLoadingBuildingEmployees.value) return
        const requestId = ++buildingEmployeesRequestId
        isLoadingBuildingEmployees.value = true
        try {
            if (selectedFloorId.value === 0) {
                currentBuildingEmployees.value = []
                buildingEmployeesTotal.value = 0
                return
            }
            const response = await buildingRepository.getCurrentFloorEmployees(selectedFloorId.value, {
                search: buildingEmployeesSearch.value,
                offset: buildingEmployeesOffset.value,
                limit: buildingEmployeesLimit.value
            })
            if (requestId !== buildingEmployeesRequestId) return
            currentBuildingEmployees.value = buildingEmployeesOffset.value === 0
                ? response.data.items
                : [...currentBuildingEmployees.value, ...response.data.items]
            buildingEmployeesTotal.value = response.data.total
        } catch {
            if (requestId !== buildingEmployeesRequestId) return
            if (buildingEmployeesOffset.value === 0) {
                currentBuildingEmployees.value = []
                buildingEmployeesTotal.value = 0
            }
        } finally {
            if (requestId === buildingEmployeesRequestId) isLoadingBuildingEmployees.value = false
        }
    }

    const matchesBuildingEmployeesSearch = (
        employee: Pick<CurrentBuildingEmployee, 'full_name' | 'email' | 'zone_title'>
    ) => {
        const query = buildingEmployeesSearch.value.trim().toLowerCase()
        if (!query) return true

        return [employee.full_name, employee.email, employee.zone_title]
            .some((value) => value.toLowerCase().includes(query))
    }

    const updateCurrentBuildingEmployeesFromLocation = (payload: EmployeeLocationSocketPayload) => {
        const existingIndex = currentBuildingEmployees.value.findIndex((item) => item.employee_id === payload.employee_id)
        const isOnSelectedFloor = payload.floor_id === selectedFloorId.value

        if (!isOnSelectedFloor || payload.zone_id === null) {
            if (existingIndex >= 0) {
                currentBuildingEmployees.value = currentBuildingEmployees.value.filter((item) => item.employee_id !== payload.employee_id)
                buildingEmployeesTotal.value = Math.max(0, buildingEmployeesTotal.value - 1)
            }
            return
        }

        const zone = zones.value.find((item) => item.zone_id === payload.zone_id)
        const nextEmployee: CurrentBuildingEmployee = {
            employee_id: payload.employee_id,
            full_name: payload.full_name,
            email: payload.email,
            photo: buildingEmployeePhotoService.resolveEmployeePhotoUrl(payload.photo),
            zone_id: payload.zone_id,
            zone_title: zone?.title || '',
            floor_id: payload.floor_id,
            last_scan_at: payload.timestamp
        }

        if (!matchesBuildingEmployeesSearch(nextEmployee)) {
            if (existingIndex >= 0) {
                currentBuildingEmployees.value = currentBuildingEmployees.value.filter((item) => item.employee_id !== payload.employee_id)
                buildingEmployeesTotal.value = Math.max(0, buildingEmployeesTotal.value - 1)
            }
            return
        }

        if (buildingEmployeesOffset.value === 0) {
            const withoutEmployee = currentBuildingEmployees.value.filter((item) => item.employee_id !== payload.employee_id)
            currentBuildingEmployees.value = [nextEmployee, ...withoutEmployee].slice(0, buildingEmployeesLimit.value)
        } else if (existingIndex >= 0) {
            currentBuildingEmployees.value = currentBuildingEmployees.value.map((item) =>
                item.employee_id === payload.employee_id ? nextEmployee : item
            )
        }

        if (existingIndex < 0) {
            buildingEmployeesTotal.value += 1
        }
    }

    const connectLocationsSocket = () => {
        if (
            buildingMapMode.value !== BuildingMapMode.VIEW ||
            buildingId.value === 0 ||
            selectedFloorId.value === 0
        ) {
            buildingLocationsSocketService.disconnect()
            return
        }

        buildingLocationsSocketService.connect(
            authStore.orgToken || '',
            buildingId.value,
            selectedFloorId.value
        )
    }

    const getSelectedEmployeeId = () => {
        if (!selectedMemberProfile.value || selectedMemberProfile.value.role !== 'employee') return null
        return selectedMemberProfile.value.id
    }

    const fetchAssignedMemberPositions = async () => {
        const employeeId = getSelectedEmployeeId()
        if (employeeId === null || building.value.organization_id === 0) {
            assignedMemberPositions.value = []
            assignedPositionsTotal.value = 0
            return
        }

        isLoadingMemberPositions.value = true
        try {
            const response = await positionsRepository.getMemberPositions(building.value.organization_id, employeeId, {
                search: assignedPositionsSearchValue.value,
                offset: assignedPositionsOffset.value,
                limit: memberPositionsLimit
            })
            assignedMemberPositions.value = assignedPositionsOffset.value === 0
                ? response.data.items
                : [...assignedMemberPositions.value, ...response.data.items]
            assignedPositionsTotal.value = response.data.total
        } finally {
            isLoadingMemberPositions.value = false
        }
    }

    const fetchAvailableMemberPositions = async () => {
        const employeeId = getSelectedEmployeeId()
        if (employeeId === null || building.value.organization_id === 0) {
            availableMemberPositions.value = []
            availablePositionsTotal.value = 0
            return
        }

        isLoadingAvailablePositions.value = true
        try {
            const response = await positionsRepository.getUnassignedEmployeePositions(building.value.organization_id, employeeId, {
                search: availablePositionsSearchValue.value,
                offset: availablePositionsOffset.value,
                limit: memberPositionsLimit
            })
            availableMemberPositions.value = availablePositionsOffset.value === 0
                ? response.data.items
                : [...availableMemberPositions.value, ...response.data.items]
            availablePositionsTotal.value = response.data.total
        } finally {
            isLoadingAvailablePositions.value = false
        }
    }

    const updateBuildingMapMode = (mode: BuildingMapMode) => {
        buildingMapMode.value = mode
        void syncMapModeToRoute(mode)
        if (mode === BuildingMapMode.VIEW) {
            connectLocationsSocket()
            return
        }
        if (sidePanelTab.value === 'employees') selectSidePanelTab('floors')
        buildingLocationsSocketService.disconnect()
    }

    const selectSidePanelTab = (tab: 'floors' | 'employees') => {
        if (tab === 'employees' && areSidebarTabsHidden.value) {
            tab = 'floors'
        }
        sidePanelTab.value = tab
        void syncSidePanelTabToRoute(tab)
        if (tab === 'floors') {
            floorsOffset.value = 0
        } else {
            buildingEmployeesOffset.value = 0
        }
        if (tab === 'employees') runBackground(fetchCurrentBuildingEmployees())
    }

    const getRoleLabel = (role: OrganizationMemberProfile['role']) => {
        if (role === 'organization_admin') return translations.value.organizationAdmin.page.table.roleLabels.organizationAdmin
        if (role === 'tag_admin') return translations.value.organizationAdmin.page.table.roleLabels.tagAdmin
        return translations.value.organizationAdmin.page.table.roleLabels.employee
    }

    const openBuildingEmployeeInfo = async (employee: CurrentBuildingEmployee) => {
        if (building.value.organization_id === 0) return
        isMemberPositionsModalOpen.value = false
        isMemberInfoModalOpen.value = true
        isLoadingMemberProfile.value = true
        selectedMemberProfile.value = {
            id: employee.employee_id,
            full_name: employee.full_name,
            email: employee.email,
            phone: null,
            photo: employee.photo,
            role: 'employee',
            created_at: employee.last_scan_at || ''
        }

        try {
            const response = await participantsControlRepository.getMemberProfile(
                building.value.organization_id,
                employee.employee_id,
                'employee'
            )
            selectedMemberProfile.value = response.data
        } finally {
            isLoadingMemberProfile.value = false
        }
    }

    const openEmployeeLocationInfo = (employee: EmployeeLocation) => {
        const zone = zones.value.find((item) => item.zone_id === employee.zone_id)
        void openBuildingEmployeeInfo({
            employee_id: employee.employee_id,
            full_name: employee.full_name,
            email: employee.email,
            photo: employee.photo,
            zone_id: employee.zone_id,
            zone_title: zone?.title || '',
            floor_id: selectedFloorId.value,
            last_scan_at: null
        })
    }

    const closeMemberInfoModal = () => {
        isMemberInfoModalOpen.value = false
    }

    const closeMemberPositionsModal = () => {
        isMemberPositionsModalOpen.value = false
        isPositionsEditMode.value = false
    }

    const expelModalMessage = computed(() => {
        if (!employeeToExpel.value) return ''
        return `${translations.value.organizationAdmin.page.modals.expelMember.messageEmployee} "${employeeToExpel.value.full_name}"?`
    })

    const openExpelModal = (employee: CurrentBuildingEmployee) => {
        employeeToExpel.value = employee
        isExpelModalOpen.value = true
    }

    const closeExpelModal = () => {
        if (isExpellingMember.value) return
        employeeToExpel.value = null
        isExpelModalOpen.value = false
    }

    const confirmExpelMember = async () => {
        if (!employeeToExpel.value || building.value.organization_id === 0) return
        isExpellingMember.value = true
        try {
            await participantsControlRepository.removeEmployee(building.value.organization_id, employeeToExpel.value.employee_id)
            currentBuildingEmployees.value = currentBuildingEmployees.value.filter((employee) =>
                employee.employee_id !== employeeToExpel.value?.employee_id
            )
            buildingEmployeesTotal.value = Math.max(0, buildingEmployeesTotal.value - 1)
        } finally {
            isExpellingMember.value = false
            closeExpelModal()
        }
    }

    const viewMemberPositions = async () => {
        if (getSelectedEmployeeId() === null) return
        isMemberInfoModalOpen.value = false
        isMemberPositionsModalOpen.value = true
        isPositionsEditMode.value = false
        assignedPositionsOffset.value = 0
        availablePositionsOffset.value = 0
        assignedPositionsSearchValue.value = ''
        availablePositionsSearchValue.value = ''
        availableMemberPositions.value = []
        await fetchAssignedMemberPositions()
    }

    const backToMemberInfo = () => {
        isMemberPositionsModalOpen.value = false
        isPositionsEditMode.value = false
        isMemberInfoModalOpen.value = true
    }

    const startEditMemberPositions = async () => {
        isPositionsEditMode.value = true
        availablePositionsOffset.value = 0
        await fetchAvailableMemberPositions()
    }

    const finishEditMemberPositions = () => {
        isPositionsEditMode.value = false
        availablePositionsSearchValue.value = ''
        availableMemberPositions.value = []
    }

    const openCreatePositionModal = () => {
        positionModalMode.value = 'create'
        positionToEditId.value = null
        positionRoleValue.value = ''
        positionDescriptionValue.value = ''
        initialPositionRoleValue.value = ''
        initialPositionDescriptionValue.value = ''
        isPositionUpsertModalOpen.value = true
    }

    const openEditPositionModal = (positionId: number) => {
        const targetPosition = assignedMemberPositions.value.find((position) => position.position_id === positionId)
            || availableMemberPositions.value.find((position) => position.position_id === positionId)
        if (!targetPosition) return

        positionModalMode.value = 'edit'
        positionToEditId.value = targetPosition.position_id
        positionRoleValue.value = targetPosition.role
        positionDescriptionValue.value = targetPosition.description || ''
        initialPositionRoleValue.value = targetPosition.role.trim()
        initialPositionDescriptionValue.value = (targetPosition.description || '').trim()
        isPositionUpsertModalOpen.value = true
    }

    const closePositionUpsertModal = () => {
        if (isPositionSubmitting.value) return
        isPositionUpsertModalOpen.value = false
    }

    const submitPosition = async () => {
        if (!canSubmitPositionForm.value || building.value.organization_id === 0) return
        isPositionSubmitting.value = true
        try {
            const normalizedDescription = positionDescriptionValue.value.trim()
            const payload = {
                role: positionRoleValue.value.trim(),
                description: normalizedDescription.length > 0 ? normalizedDescription : null
            }
            if (positionModalMode.value === 'create') {
                const response = await positionsRepository.createPosition({
                    organization_id: building.value.organization_id,
                    ...payload
                })
                if (isPositionsEditMode.value) {
                    availableMemberPositions.value = [response.data, ...availableMemberPositions.value]
                    availablePositionsTotal.value += 1
                }
            } else if (positionToEditId.value !== null) {
                await positionsRepository.updatePosition(positionToEditId.value, payload)
                assignedMemberPositions.value = assignedMemberPositions.value.map((position) =>
                    position.position_id === positionToEditId.value ? { ...position, ...payload } : position
                )
                availableMemberPositions.value = availableMemberPositions.value.map((position) =>
                    position.position_id === positionToEditId.value ? { ...position, ...payload } : position
                )
            }
            closePositionUpsertModal()
        } finally {
            isPositionSubmitting.value = false
        }
    }

    const openDeletePositionModal = (positionId: number) => {
        positionToDeleteId.value = positionId
        isDeletePositionModalOpen.value = true
    }

    const closeDeletePositionModal = () => {
        if (isDeletingPosition.value) return
        positionToDeleteId.value = null
        isDeletePositionModalOpen.value = false
    }

    const confirmDeletePosition = async () => {
        if (positionToDeleteId.value === null) return
        isDeletingPosition.value = true
        try {
            await positionsRepository.deletePosition(positionToDeleteId.value)
            assignedMemberPositions.value = assignedMemberPositions.value.filter((position) => position.position_id !== positionToDeleteId.value)
            availableMemberPositions.value = availableMemberPositions.value.filter((position) => position.position_id !== positionToDeleteId.value)
            assignedPositionsTotal.value = Math.max(0, assignedPositionsTotal.value - 1)
            availablePositionsTotal.value = Math.max(0, availablePositionsTotal.value - 1)
            closeDeletePositionModal()
        } finally {
            isDeletingPosition.value = false
        }
    }

    const assignPositionToMember = async (positionId: number) => {
        const employeeId = getSelectedEmployeeId()
        if (employeeId === null || !isPositionsEditMode.value) return
        isLoadingMemberPositions.value = true
        isLoadingAvailablePositions.value = true
        try {
            await positionsRepository.assignPosition(employeeId, positionId)
            availableMemberPositions.value = availableMemberPositions.value.filter((position) => position.position_id !== positionId)
            availablePositionsTotal.value = Math.max(0, availablePositionsTotal.value - 1)
            assignedPositionsOffset.value = 0
            await fetchAssignedMemberPositions()
        } finally {
            isLoadingMemberPositions.value = false
            isLoadingAvailablePositions.value = false
        }
    }

    const unassignPositionFromMember = async (positionId: number) => {
        const employeeId = getSelectedEmployeeId()
        if (employeeId === null || !isPositionsEditMode.value) return
        isLoadingMemberPositions.value = true
        isLoadingAvailablePositions.value = true
        try {
            await positionsRepository.unassignPosition(employeeId, positionId)
            assignedMemberPositions.value = assignedMemberPositions.value.filter((position) => position.position_id !== positionId)
            assignedPositionsTotal.value = Math.max(0, assignedPositionsTotal.value - 1)
            if (isPositionsEditMode.value) {
                availablePositionsOffset.value = 0
                await fetchAvailableMemberPositions()
            }
        } finally {
            isLoadingMemberPositions.value = false
            isLoadingAvailablePositions.value = false
        }
    }

    const openEditBuildingModal = () => {
        buildingTitleValue.value = building.value.title
        buildingAddressValue.value = building.value.address || ''
        initialBuildingTitleValue.value = building.value.title.trim()
        initialBuildingAddressValue.value = (building.value.address || '').trim()
        isBuildingModalOpen.value = true
    }

    const closeBuildingModal = () => {
        isBuildingModalOpen.value = false
    }

    const submitBuilding = async () => {
        if (!canSubmitBuilding.value) return
        isBuildingSubmitting.value = true
        try {
            const address = buildingAddressValue.value.trim()
            const response = await buildingEditDeleteRepository.updateBuilding(buildingId.value, {
                title: buildingTitleValue.value.trim(),
                address: address.length > 0 ? address : null
            })
            building.value = response.data
            closeBuildingModal()
        } finally {
            isBuildingSubmitting.value = false
        }
    }

    const openCreateFloorModal = () => {
        floorModalMode.value = 'create'
        floorEditingId.value = 0
        floorNameValue.value = ''
        initialFloorNameValue.value = ''
        isFloorModalOpen.value = true
    }

    const openEditFloorModal = (floor: FloorItem) => {
        floorModalMode.value = 'edit'
        floorEditingId.value = floor.floor_id
        floorNameValue.value = floor.floor_name
        initialFloorNameValue.value = floor.floor_name.trim()
        isFloorModalOpen.value = true
    }

    const closeFloorModal = () => {
        isFloorModalOpen.value = false
    }

    const submitFloor = async () => {
        if (!canSubmitFloor.value) return
        isFloorSubmitting.value = true
        try {
            if (floorModalMode.value === 'create') {
                await buildingRepository.createFloor(buildingId.value, {
                    floor_number: floorsTotal.value + 1,
                    floor_name: floorNameValue.value.trim()
                })
                await reloadFloors()
                const created = floors.value.find((item) => item.floor_name === floorNameValue.value.trim())
                if (created) {
                    selectedFloorId.value = created.floor_id
                }
            } else {
                await buildingRepository.updateFloorName(floorEditingId.value, floorNameValue.value.trim())
                floors.value = floors.value.map((floor) => floor.floor_id === floorEditingId.value
                    ? { ...floor, floor_name: floorNameValue.value.trim() }
                    : floor)
            }
            closeFloorModal()
        } finally {
            isFloorSubmitting.value = false
        }
    }

    const reorderFloor = async (floor: FloorItem, direction: -1 | 1) => {
        const nextNumber = floor.floor_number + direction
        if (nextNumber < 1 || nextNumber > floorsTotal.value) return
        await buildingRepository.reorderFloor(floor.floor_id, nextNumber)
        await reloadFloors()
    }

    const startFloorDrag = (floor: FloorItem, event: DragEvent) => {
        event.dataTransfer?.setData('text/plain', String(floor.floor_id))
        if (event.dataTransfer) {
            event.dataTransfer.effectAllowed = 'move'
        }
        draggedFloorId.value = floor.floor_id
        dragOverFloorId.value = floor.floor_id
    }

    const moveFloorDrag = (floor: FloorItem) => {
        if (draggedFloorId.value === 0 || dragOverFloorId.value === floor.floor_id) return
        dragOverFloorId.value = floor.floor_id
    }

    const finishFloorDrag = async () => {
        if (draggedFloorId.value === 0 || dragOverFloorId.value === 0 || draggedFloorId.value === dragOverFloorId.value) {
            draggedFloorId.value = 0
            dragOverFloorId.value = 0
            return
        }
        const target = displayedFloors.value.find((floor) => floor.floor_id === draggedFloorId.value)
        const floorId = draggedFloorId.value
        draggedFloorId.value = 0
        dragOverFloorId.value = 0
        if (!target) return
        await buildingRepository.reorderFloor(floorId, target.floor_number)
        await reloadFloors()
    }

    const cancelFloorDrag = () => {
        draggedFloorId.value = 0
        dragOverFloorId.value = 0
    }

    const openDeleteFloorModal = (floorId: number) => {
        floorToDeleteId.value = floorId
    }

    const closeDeleteFloorModal = () => {
        floorToDeleteId.value = 0
    }

    const confirmDeleteFloor = async () => {
        if (floorToDeleteId.value === 0) return
        isDeletingFloor.value = true
        try {
            const deletedFloorIndex = floors.value.findIndex((floor) => floor.floor_id === floorToDeleteId.value)
            const fallbackFloorId = deletedFloorIndex > 0
                ? floors.value[deletedFloorIndex - 1]?.floor_id
                : floors.value.find((floor) => floor.floor_id !== floorToDeleteId.value)?.floor_id
            await buildingRepository.deleteFloor(floorToDeleteId.value)
            floors.value = floors.value.filter((floor) => floor.floor_id !== floorToDeleteId.value)
            floorsTotal.value = Math.max(0, floorsTotal.value - 1)
            if (selectedFloorId.value === floorToDeleteId.value) {
                selectedFloorId.value = fallbackFloorId || floors.value[0]?.floor_id || 0
            }
            closeDeleteFloorModal()
            await reloadFloors()
        } finally {
            isDeletingFloor.value = false
        }
    }

    const openDeleteBuildingModal = () => {
        isDeleteBuildingModalOpen.value = true
    }

    const closeDeleteBuildingModal = () => {
        isDeleteBuildingModalOpen.value = false
    }

    const confirmDeleteBuilding = async () => {
        await buildingEditDeleteRepository.deleteBuilding(buildingId.value)
        await router.push({ name: 'Organizations' })
    }

    const toggleFloorsCollapsed = () => {
        if (floorsCollapseTimeout !== null) {
            window.clearTimeout(floorsCollapseTimeout)
        }

        if (!isFloorsCollapsed.value) {
            isFloorsCollapsed.value = true
            void syncFloorsStateToRoute(true)
            floorsCollapseTimeout = window.setTimeout(() => {
                isBuildingMapExpanded.value = true
            }, BUILDING_MAP_PREVIEW_CONSTANTS.FLOORS_COLLAPSE_ANIMATION_MS)
            return
        }

        isBuildingMapExpanded.value = false
        void syncFloorsStateToRoute(false)
        floorsCollapseTimeout = window.setTimeout(() => {
            isFloorsCollapsed.value = false
        }, BUILDING_MAP_PREVIEW_CONSTANTS.FLOORS_COLLAPSE_ANIMATION_MS)
    }

    onMounted(() => {
        unsubscribeLocationListener = buildingLocationsSocketService.addListener(updateCurrentBuildingEmployeesFromLocation)
        applyFloorsStateImmediately(getFloorsStateFromQuery())
        if (route.query.floors !== 'collapsed' && route.query.floors !== 'expanded') {
            void syncFloorsStateToRoute(false)
        }
        runBackground(fetchBuilding())
        runBackground(fetchFloors())
    })

    watch(
        () => route.query.floors,
        () => {
            applyFloorsStateImmediately(getFloorsStateFromQuery())
        }
    )

    watch(selectedFloorId, () => {
        void syncSelectedFloorToRoute(selectedFloorId.value)
        runBackground(fetchMap())
        buildingEmployeesOffset.value = 0
        if (sidePanelTab.value === 'employees') runBackground(fetchCurrentBuildingEmployees())
        connectLocationsSocket()
    })

    watch(
        () => route.query.floor,
        () => {
            const floorFromRoute = Number(route.query.floor)
            if (!floorFromRoute || selectedFloorId.value === floorFromRoute) return
            if (floors.value.some((floor) => floor.floor_id === floorFromRoute)) {
                selectedFloorId.value = floorFromRoute
            }
        }
    )

    watch(
        () => route.query.tab,
        () => {
            const tab = route.query.tab === 'employees' ? 'employees' : 'floors'
            if (sidePanelTab.value !== tab) selectSidePanelTab(tab)
        }
    )

    watch(areSidebarTabsHidden, (value) => {
        if (value && sidePanelTab.value === 'employees') selectSidePanelTab('floors')
    })

    watch(
        () => route.query.mode,
        () => {
            const mode = route.query.mode === BuildingMapMode.VIEW ? BuildingMapMode.VIEW : BuildingMapMode.EDIT
            if (buildingMapMode.value !== mode) updateBuildingMapMode(mode)
        }
    )

    watch(viewport, () => {
        scheduleMapSync()
    })

    watch(floorsSearch, () => {
        if (floorsOffset.value !== 0) {
            floorsOffset.value = 0
            return
        }
        if (floorsSearchDebounce !== null) {
            window.clearTimeout(floorsSearchDebounce)
        }
        if (floorsCollapseTimeout !== null) {
            window.clearTimeout(floorsCollapseTimeout)
        }
        floorsSearchDebounce = window.setTimeout(() => {
            runBackground(fetchFloors())
        }, LIST.SEARCH_DEBOUNCE_MS)
    })

    watch(buildingEmployeesSearch, () => {
        if (buildingEmployeesOffset.value !== 0) {
            buildingEmployeesOffset.value = 0
            return
        }
        if (buildingEmployeesSearchDebounce !== null) window.clearTimeout(buildingEmployeesSearchDebounce)
        buildingEmployeesSearchDebounce = window.setTimeout(() => {
            runBackground(fetchCurrentBuildingEmployees())
        }, LIST.SEARCH_DEBOUNCE_MS)
    })

    watch(floorsOffset, () => {
        runBackground(fetchFloors())
    })

    watch(buildingEmployeesOffset, () => {
        runBackground(fetchCurrentBuildingEmployees())
    })

    watch(assignedPositionsSearchValue, () => {
        assignedPositionsOffset.value = 0
        if (!isMemberPositionsModalOpen.value) return
        if (assignedPositionsSearchDebounce !== null) window.clearTimeout(assignedPositionsSearchDebounce)
        assignedPositionsSearchDebounce = window.setTimeout(() => {
            runBackground(fetchAssignedMemberPositions())
        }, LIST.SEARCH_DEBOUNCE_MS)
    })

    watch(assignedPositionsOffset, () => {
        if (isMemberPositionsModalOpen.value) runBackground(fetchAssignedMemberPositions())
    })

    watch(availablePositionsSearchValue, () => {
        availablePositionsOffset.value = 0
        if (!isMemberPositionsModalOpen.value || !isPositionsEditMode.value) return
        if (availablePositionsSearchDebounce !== null) window.clearTimeout(availablePositionsSearchDebounce)
        availablePositionsSearchDebounce = window.setTimeout(() => {
            runBackground(fetchAvailableMemberPositions())
        }, LIST.SEARCH_DEBOUNCE_MS)
    })

    watch(availablePositionsOffset, () => {
        if (isMemberPositionsModalOpen.value && isPositionsEditMode.value) runBackground(fetchAvailableMemberPositions())
    })

    watch(readersSearch, () => {
        if (readersOffset.value !== 0) {
            readersOffset.value = 0
            return
        }
        if (readersSearchDebounce !== null) window.clearTimeout(readersSearchDebounce)
        readersSearchDebounce = window.setTimeout(() => {
            runBackground(fetchDoorReaders())
        }, LIST.SEARCH_DEBOUNCE_MS)
    })

    watch(readersOffset, () => {
        runBackground(fetchDoorReaders())
    })

    onBeforeUnmount(() => {
        if (floorsSearchDebounce !== null) {
            window.clearTimeout(floorsSearchDebounce)
        }
        if (readersSearchDebounce !== null) {
            window.clearTimeout(readersSearchDebounce)
        }
        if (buildingEmployeesSearchDebounce !== null) {
            window.clearTimeout(buildingEmployeesSearchDebounce)
        }
        if (assignedPositionsSearchDebounce !== null) {
            window.clearTimeout(assignedPositionsSearchDebounce)
        }
        if (availablePositionsSearchDebounce !== null) {
            window.clearTimeout(availablePositionsSearchDebounce)
        }
        unsubscribeLocationListener?.()
        unsubscribeLocationListener = null
        buildingLocationsSocketService.disconnect()
    })

    return {
        building,
        formatDate,
        formattedCreatedAt,
        floors,
        displayedFloors,
        draggedFloorId,
        zones,
        transitionValidationZones,
        transitionValidationDoors,
        deletableZoneIds,
        deletableDoorIds,
        doors,
        currentBuildingEmployees,
        sidePanelTab,
        selectedFloorId,
        floorsSearch,
        buildingEmployeesSearch,
        floorsOffset,
        buildingEmployeesOffset,
        floorsLimit,
        buildingEmployeesLimit,
        floorsTotal,
        buildingEmployeesTotal,
        viewport,
        buildingMapMode,
        areSidebarTabsHidden,
        isFloorsCollapsed,
        isBuildingMapExpanded,
        isLoadingBuilding,
        isLoadingFloors,
        isLoadingBuildingEmployees,
        isExpelModalOpen,
        isExpellingMember,
        isLoadingMap,
        selectedMemberProfile,
        isMemberInfoModalOpen,
        isLoadingMemberProfile,
        isMemberPositionsModalOpen,
        isPositionsEditMode,
        isLoadingMemberPositions,
        isLoadingAvailablePositions,
        assignedMemberPositions,
        availableMemberPositions,
        assignedPositionsSearchValue,
        availablePositionsSearchValue,
        assignedPositionsOffset,
        availablePositionsOffset,
        assignedPositionsTotal,
        availablePositionsTotal,
        memberPositionsLimit,
        isPositionUpsertModalOpen,
        positionModalMode,
        positionRoleValue,
        positionDescriptionValue,
        isPositionSubmitting,
        canSubmitPositionForm,
        isDeletePositionModalOpen,
        isDeletingPosition,
        isBuildingModalOpen,
        buildingTitleValue,
        buildingAddressValue,
        isBuildingSubmitting,
        canSubmitBuilding,
        isFloorModalOpen,
        floorModalMode,
        floorNameValue,
        isFloorSubmitting,
        canSubmitFloor,
        isZoneCreateModalOpen,
        zoneTitleValue,
        zoneIsTransitionBetweenFloors,
        zoneCanCreateTransition,
        zoneCreateErrorMessage,
        isZoneSubmitting,
        isEditingZone,
        accessRulesZoneId,
        accessRulesZoneTitle,
        canSubmitZone,
        canDeleteFloor,
        isDeleteBuildingModalOpen,
        floorToDeleteId,
        isDeletingFloor,
        zoneToDeleteId,
        isDeletingZone,
        doorToDelete,
        isDeletingDoor,
        readerDoorId,
        selectedDoorReader,
        availableReaders,
        readersSearch,
        readersOffset,
        readersLimit,
        readersTotal,
        isLoadingReaders,
        generatedReaderToken,
        isReaderModalOpen,
        readerModalMode,
        readerNameValue,
        isReaderSubmitting,
        readerToDelete,
        isDeletingReader,
        readerToRegenerate,
        isRegeneratingReaderToken,
        readerTokenCopySuccessMessage,
        canSubmitReader,
        expelModalMessage,
        openEditBuildingModal,
        closeBuildingModal,
        submitBuilding,
        openCreateFloorModal,
        openEditFloorModal,
        closeFloorModal,
        submitFloor,
        reorderFloor,
        startFloorDrag,
        moveFloorDrag,
        finishFloorDrag,
        cancelFloorDrag,
        openDeleteFloorModal,
        closeDeleteFloorModal,
        confirmDeleteFloor,
        openDeleteBuildingModal,
        closeDeleteBuildingModal,
        confirmDeleteBuilding,
        updateViewport,
        updateBuildingMapMode,
        selectSidePanelTab,
        openBuildingEmployeeInfo,
        openEmployeeLocationInfo,
        openExpelModal,
        closeExpelModal,
        confirmExpelMember,
        closeMemberInfoModal,
        closeMemberPositionsModal,
        viewMemberPositions,
        backToMemberInfo,
        startEditMemberPositions,
        finishEditMemberPositions,
        openCreatePositionModal,
        openEditPositionModal,
        closePositionUpsertModal,
        submitPosition,
        openDeletePositionModal,
        closeDeletePositionModal,
        confirmDeletePosition,
        assignPositionToMember,
        unassignPositionFromMember,
        getRoleLabel,
        toggleFloorsCollapsed,
        commitZoneGeometry,
        shiftZone,
        updateZoneTitle,
        updateZonePhoto,
        openZoneAccessRulesModal,
        closeZoneAccessRulesModal,
        addZone,
        closeZoneCreateModal,
        submitZone,
        openDeleteZoneModal,
        closeDeleteZoneModal,
        confirmDeleteZone,
        addDoor,
        openDeleteDoorModal,
        closeDeleteDoorModal,
        confirmDeleteDoor,
        openDoorReaderModal,
        closeDoorReaderModal,
        assignReaderToDoor,
        unassignReaderFromDoor,
        openRegenerateReaderTokenModal,
        closeRegenerateReaderTokenModal,
        confirmRegenerateReaderToken,
        openDeleteReaderModal,
        closeDeleteReaderModal,
        confirmDeleteReader,
        openCreateReaderModal,
        openEditReaderModal,
        closeReaderModal,
        submitReader,
        copyGeneratedReaderToken
    }
}
