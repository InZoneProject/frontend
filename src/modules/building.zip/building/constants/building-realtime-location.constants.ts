export const BUILDING_REALTIME_LOCATION_CONSTANTS = {
    SCANNED_DOOR_FLASH_MS: 1100,
    DEDUPE_WINDOW_MS: 1000,
    NAMESPACE: '/locations',
    EVENTS: {
        SUBSCRIBE_BUILDING: 'subscribe_building',
        UNSUBSCRIBE_BUILDING: 'unsubscribe_building',
        SUBSCRIBE_FLOOR: 'subscribe_floor',
        UNSUBSCRIBE_FLOOR: 'unsubscribe_floor',
        EMPLOYEE_LOCATION: 'employee.location'
    }
} as const
