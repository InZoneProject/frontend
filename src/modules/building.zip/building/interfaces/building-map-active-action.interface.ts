import type {ZoneMapItem} from '@/modules/building/interfaces/zone-map-item.interface'

export type BuildingMapResizeEdge =
    'left'
    | 'right'
    | 'top'
    | 'bottom'
    | 'top-left'
    | 'top-right'
    | 'bottom-left'
    | 'bottom-right'

export type BuildingMapActiveAction = {
    type: 'move'
    zone: ZoneMapItem
    startClientX: number
    startClientY: number
    startX: number
    startY: number
    currentDeltaX: number
    currentDeltaY: number
    lastValidDeltaX: number
    lastValidDeltaY: number
    hasLoadedDependencies: boolean
} | {
    type: 'resize'
    zone: ZoneMapItem
    edge: BuildingMapResizeEdge
    startClientX: number
    startClientY: number
    startX: number
    startY: number
    startWidth: number
    startHeight: number
    lastValidDeltaX: number
    lastValidDeltaY: number
    currentDeltaX: number
    currentDeltaY: number
    hasLoadedDependencies: boolean
} | {
    type: 'pan'
    startClientX: number
    startClientY: number
    startPanX: number
    startPanY: number
    currentPanX: number
    currentPanY: number
}
