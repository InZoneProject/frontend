import type { CurrentBuildingEmployee } from '@/modules/building/interfaces/current-building-employee.interface'
import type { FloorItem } from '@/modules/building/interfaces/floor-item.interface'

export interface BuildingViewSidebarEmits {
    (event: 'update:floorsSearch', value: string): void
    (event: 'update:buildingEmployeesSearch', value: string): void
    (event: 'update:floorsOffset', value: number): void
    (event: 'update:buildingEmployeesOffset', value: number): void
    (event: 'update:selectedFloorId', value: number): void
    (event: 'selectSidePanelTab', value: 'floors' | 'employees'): void
    (event: 'toggleFloorsCollapsed'): void
    (event: 'openCreateFloorModal'): void
    (event: 'openEditFloorModal', floor: FloorItem): void
    (event: 'openDeleteFloorModal', floorId: number): void
    (event: 'startFloorDrag', floor: FloorItem, nativeEvent: DragEvent): void
    (event: 'moveFloorDrag', floor: FloorItem): void
    (event: 'finishFloorDrag'): void
    (event: 'cancelFloorDrag'): void
    (event: 'openBuildingEmployeeInfo', employee: CurrentBuildingEmployee): void
    (event: 'openExpelModal', employee: CurrentBuildingEmployee): void
}
