export interface BuildingViewSidebarTranslations {
    floors: {
        collapse: string
        expand: string
        expandHint: string
        add: string
        title?: string
        searchPlaceholder: string
        headers: {
            position: string
            name: string
            actions: string
        }
    }
    employees: {
        title?: string
        searchPlaceholder: string
        empty: string
        headers: {
            user: string
            actions: string
        }
    }
}
