export interface ViewportBounds {
    x: number
    y: number
    width: number
    height: number
}

export interface ViewportPageParams extends ViewportBounds {
    cursor?: number
    limit?: number
}
