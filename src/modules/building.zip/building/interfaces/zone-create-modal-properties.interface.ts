export interface ZoneCreateModalProperties {
    isOpen: boolean
    titleValue: string
    isTransitionBetweenFloors: boolean
    canCreateTransition: boolean
    errorMessage: string
    loading: boolean
    canSubmit: boolean
}
