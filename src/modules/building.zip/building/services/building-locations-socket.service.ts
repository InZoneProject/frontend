import { io, type Socket } from 'socket.io-client'
import { BUILDING_REALTIME_LOCATION_CONSTANTS } from '@/modules/building/constants/building-realtime-location.constants'
import type { EmployeeLocationSocketPayload } from '@/modules/building/interfaces/employee-location-socket-payload.interface'

class BuildingLocationsSocketService {
    private static instance: BuildingLocationsSocketService | null = null
    private socket: Socket | null = null
    private activeToken = ''
    private activeBuildingId = 0
    private activeFloorId = 0
    private listeners = new Set<(payload: EmployeeLocationSocketPayload) => void>()
    private recentEventKeys = new Map<string, number>()

    private constructor() {}

    static getInstance(): BuildingLocationsSocketService {
        if (!BuildingLocationsSocketService.instance) {
            BuildingLocationsSocketService.instance = new BuildingLocationsSocketService()
        }

        return BuildingLocationsSocketService.instance
    }

    private resolveSocketBaseUrl(): string {
        const apiBaseUrl = String(import.meta.env.VITE_API_BASE_URL || '')
        const origin = apiBaseUrl ? new URL(apiBaseUrl, window.location.origin).origin : window.location.origin
        return `${origin}${BUILDING_REALTIME_LOCATION_CONSTANTS.NAMESPACE}`
    }

    connect(token: string, buildingId: number, floorId: number): void {
        if (!token || buildingId === 0 || floorId === 0) return

        if (
            this.socket
            && this.activeToken === token
            && this.activeBuildingId === buildingId
            && this.activeFloorId === floorId
        ) {
            return
        }

        this.disconnect()
        this.activeToken = token
        this.activeBuildingId = buildingId
        this.activeFloorId = floorId

        this.socket = io(this.resolveSocketBaseUrl(), {
            transports: ['websocket', 'polling'],
            auth: {
                token: `Bearer ${token}`
            }
        })

        this.socket.on('connect', () => {
            this.socket?.emit(BUILDING_REALTIME_LOCATION_CONSTANTS.EVENTS.SUBSCRIBE_BUILDING, { building_id: buildingId })
            this.socket?.emit(BUILDING_REALTIME_LOCATION_CONSTANTS.EVENTS.SUBSCRIBE_FLOOR, { floor_id: floorId })
        })

        this.socket.on(BUILDING_REALTIME_LOCATION_CONSTANTS.EVENTS.EMPLOYEE_LOCATION, (payload: EmployeeLocationSocketPayload) => {
            this.emitLocation(payload)
        })
    }

    addListener(listener: (payload: EmployeeLocationSocketPayload) => void): () => void {
        this.listeners.add(listener)

        return () => {
            this.listeners.delete(listener)
        }
    }

    private emitLocation(payload: EmployeeLocationSocketPayload): void {
        const eventKey = [
            payload.employee_id,
            payload.door_id,
            payload.previous_zone_id ?? 'null',
            payload.zone_id ?? 'null',
            payload.timestamp
        ].join(':')
        const now = Date.now()
        const previousSeenAt = this.recentEventKeys.get(eventKey)

        if (previousSeenAt && now - previousSeenAt < BUILDING_REALTIME_LOCATION_CONSTANTS.DEDUPE_WINDOW_MS) {
            return
        }

        this.recentEventKeys.set(eventKey, now)
        this.cleanupRecentEventKeys(now)
        this.listeners.forEach((listener) => listener(payload))
    }

    private cleanupRecentEventKeys(now: number): void {
        this.recentEventKeys.forEach((seenAt, key) => {
            if (now - seenAt > BUILDING_REALTIME_LOCATION_CONSTANTS.DEDUPE_WINDOW_MS) {
                this.recentEventKeys.delete(key)
            }
        })
    }

    disconnect(): void {
        if (!this.socket) {
            this.activeToken = ''
            this.activeBuildingId = 0
            this.activeFloorId = 0
            this.recentEventKeys.clear()
            return
        }

        if (this.activeBuildingId > 0) {
            this.socket.emit(BUILDING_REALTIME_LOCATION_CONSTANTS.EVENTS.UNSUBSCRIBE_BUILDING, { building_id: this.activeBuildingId })
        }
        if (this.activeFloorId > 0) {
            this.socket.emit(BUILDING_REALTIME_LOCATION_CONSTANTS.EVENTS.UNSUBSCRIBE_FLOOR, { floor_id: this.activeFloorId })
        }
        this.socket.disconnect()
        this.socket = null
        this.activeToken = ''
        this.activeBuildingId = 0
        this.activeFloorId = 0
        this.recentEventKeys.clear()
    }
}

export const buildingLocationsSocketService = BuildingLocationsSocketService.getInstance()
