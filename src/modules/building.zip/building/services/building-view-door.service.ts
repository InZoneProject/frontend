import { computed, ref, type ComputedRef } from 'vue'
import { LIST } from '@/constants/list.constants'
import { buildingRepository } from '@/modules/building/repositories/building.repository'
import type { DoorMapItem } from '@/modules/building/interfaces/door-map-item.interface'
import type { RfidReaderItem } from '@/modules/building/interfaces/rfid-reader-item.interface'

export const createBuildingViewDoorState = (params: {
    doors: { value: DoorMapItem[] }
    transitionValidationDoors: { value: DoorMapItem[] }
    deletableDoorIds: { value: number[] }
    copySuccessMessage: ComputedRef<string>
}) => {
    const doorToDelete = ref<{ doorId: number; isEntrance: boolean } | null>(null)
    const isDeletingDoor = ref(false)
    const readerDoorId = ref(0)
    const selectedDoorReader = ref<RfidReaderItem | null>(null)
    const availableReaders = ref<RfidReaderItem[]>([])
    const readersSearch = ref('')
    const readersOffset = ref(0)
    const readersLimit = ref(LIST.DEFAULT_LIMIT)
    const readersTotal = ref(0)
    const isLoadingReaders = ref(false)
    const generatedReaderToken = ref('')
    const isReaderModalOpen = ref(false)
    const readerModalMode = ref<'create' | 'edit'>('create')
    const readerNameValue = ref('')
    const readerEditingId = ref(0)
    const isReaderSubmitting = ref(false)
    const readerToDelete = ref<RfidReaderItem | null>(null)
    const isDeletingReader = ref(false)
    const readerToRegenerate = ref<RfidReaderItem | null>(null)
    const isRegeneratingReaderToken = ref(false)
    const readerTokenCopySuccessMessage = ref('')
    const canSubmitReader = computed(() => readerNameValue.value.trim().length > 0)

    const addDoor = async (payload: { zone_from_id: number | null; zone_to_id: number; floor_id: number; entrance_door_side?: 'top' | 'bottom' | 'left' | 'right' }) => {
        let createdDoor: DoorMapItem | null = null

        if (payload.zone_from_id === null) {
            if (!payload.entrance_door_side) return
            const response = await buildingRepository.createEntranceDoor({
                zone_id: payload.zone_to_id,
                entrance_door_side: payload.entrance_door_side,
                floor_id: payload.floor_id
            })
            createdDoor = {
                door_id: response.data.door_id,
                is_entrance: true,
                entrance_door_side: response.data.entrance_door_side,
                zone_from_id: null,
                zone_to_id: response.data.zone_id,
                floor_id: response.data.floor_id,
                rfid_reader_id: null
            }
        } else {
            const response = await buildingRepository.createDoor({
                zone_from_id: payload.zone_from_id,
                zone_to_id: payload.zone_to_id,
                floor_id: payload.floor_id
            })
            createdDoor = {
                door_id: response.data.door_id,
                is_entrance: false,
                entrance_door_side: null,
                zone_from_id: response.data.zone_from_id,
                zone_to_id: response.data.zone_to_id,
                floor_id: response.data.floor_id,
                rfid_reader_id: null
            }
        }

        if (createdDoor) {
            const upsertDoor = (doorList: DoorMapItem[]) => [
                ...doorList.filter((door) => door.door_id !== createdDoor!.door_id),
                createdDoor!
            ]

            params.doors.value = upsertDoor(params.doors.value)
            params.transitionValidationDoors.value = upsertDoor(params.transitionValidationDoors.value)
            if (!params.deletableDoorIds.value.includes(createdDoor.door_id)) {
                params.deletableDoorIds.value = [...params.deletableDoorIds.value, createdDoor.door_id]
            }
        }
    }

    const openDeleteDoorModal = (doorId: number, isEntrance: boolean) => {
        doorToDelete.value = { doorId, isEntrance }
    }

    const closeDeleteDoorModal = () => {
        if (isDeletingDoor.value) return
        doorToDelete.value = null
    }

    const confirmDeleteDoor = async () => {
        if (!doorToDelete.value) return
        isDeletingDoor.value = true
        try {
            const deletedDoor = doorToDelete.value
            await buildingRepository.deleteDoor(deletedDoor.doorId, deletedDoor.isEntrance)
            const isDeletedDoor = (door: DoorMapItem) => door.door_id === deletedDoor.doorId && door.is_entrance === deletedDoor.isEntrance
            params.doors.value = params.doors.value.filter((door) => !isDeletedDoor(door))
            params.transitionValidationDoors.value = params.transitionValidationDoors.value.filter((door) => !isDeletedDoor(door))
            params.deletableDoorIds.value = params.deletableDoorIds.value.filter((doorId) => doorId !== deletedDoor.doorId)
            doorToDelete.value = null
        } finally {
            isDeletingDoor.value = false
        }
    }

    const fetchDoorReaders = async () => {
        if (readerDoorId.value === 0) return
        isLoadingReaders.value = true
        try {
            const [selectedResponse, availableResponse] = await Promise.all([
                buildingRepository.getDoorReader(readerDoorId.value),
                buildingRepository.getAvailableReadersForDoor(readerDoorId.value, {
                    search: readersSearch.value,
                    offset: readersOffset.value,
                    limit: readersLimit.value
                })
            ])
            selectedDoorReader.value = selectedResponse.data
            availableReaders.value = availableResponse.data.items
            readersTotal.value = availableResponse.data.total
        } finally {
            isLoadingReaders.value = false
        }
    }

    const openDoorReaderModal = async (doorId: number) => {
        readerDoorId.value = doorId
        readersOffset.value = 0
        generatedReaderToken.value = ''
        await fetchDoorReaders()
    }

    const closeDoorReaderModal = () => {
        readerDoorId.value = 0
        selectedDoorReader.value = null
        availableReaders.value = []
        generatedReaderToken.value = ''
    }

    const assignReaderToDoor = async (reader: RfidReaderItem) => {
        if (readerDoorId.value === 0) return
        const previousReader = selectedDoorReader.value
        if (previousReader) await buildingRepository.removeReaderFromDoor(readerDoorId.value)
        await buildingRepository.assignReaderToDoor(readerDoorId.value, reader.rfid_reader_id)
        selectedDoorReader.value = reader
        availableReaders.value = availableReaders.value.filter((item) => item.rfid_reader_id !== reader.rfid_reader_id)
        if (previousReader) void fetchDoorReaders()
        params.doors.value = params.doors.value.map((door) =>
            door.door_id === readerDoorId.value ? { ...door, rfid_reader_id: reader.rfid_reader_id } : door
        )
        params.transitionValidationDoors.value = params.transitionValidationDoors.value.map((door) =>
            door.door_id === readerDoorId.value ? { ...door, rfid_reader_id: reader.rfid_reader_id } : door
        )
    }

    const unassignReaderFromDoor = async () => {
        if (readerDoorId.value === 0 || !selectedDoorReader.value) return
        await buildingRepository.removeReaderFromDoor(readerDoorId.value)
        selectedDoorReader.value = null
        void fetchDoorReaders()
        params.doors.value = params.doors.value.map((door) =>
            door.door_id === readerDoorId.value ? { ...door, rfid_reader_id: null } : door
        )
        params.transitionValidationDoors.value = params.transitionValidationDoors.value.map((door) =>
            door.door_id === readerDoorId.value ? { ...door, rfid_reader_id: null } : door
        )
    }

    const openRegenerateReaderTokenModal = (reader: RfidReaderItem) => {
        readerToRegenerate.value = reader
    }

    const closeRegenerateReaderTokenModal = () => {
        if (isRegeneratingReaderToken.value) return
        readerToRegenerate.value = null
    }

    const confirmRegenerateReaderToken = async () => {
        if (!readerToRegenerate.value) return
        isRegeneratingReaderToken.value = true
        try {
            const response = await buildingRepository.regenerateReaderToken(readerToRegenerate.value.rfid_reader_id)
            generatedReaderToken.value = response.data.new_secret_token
            readerToRegenerate.value = null
        } finally {
            isRegeneratingReaderToken.value = false
        }
    }

    const openDeleteReaderModal = (reader: RfidReaderItem) => {
        readerToDelete.value = reader
    }

    const closeDeleteReaderModal = () => {
        if (isDeletingReader.value) return
        readerToDelete.value = null
    }

    const confirmDeleteReader = async () => {
        if (!readerToDelete.value) return
        isDeletingReader.value = true
        try {
            const readerId = readerToDelete.value.rfid_reader_id
            await buildingRepository.deleteReader(readerId)
            if (selectedDoorReader.value?.rfid_reader_id === readerId) {
                selectedDoorReader.value = null
            }
            availableReaders.value = availableReaders.value.filter((item) => item.rfid_reader_id !== readerId)
            readersTotal.value = Math.max(0, readersTotal.value - 1)
            readerToDelete.value = null
        } finally {
            isDeletingReader.value = false
        }
    }

    const openCreateReaderModal = () => {
        readerModalMode.value = 'create'
        readerEditingId.value = 0
        readerNameValue.value = ''
        isReaderModalOpen.value = true
    }

    const openEditReaderModal = (reader: RfidReaderItem) => {
        readerModalMode.value = 'edit'
        readerEditingId.value = reader.rfid_reader_id
        readerNameValue.value = reader.name
        isReaderModalOpen.value = true
    }

    const closeReaderModal = () => {
        if (isReaderSubmitting.value) return
        isReaderModalOpen.value = false
    }

    const submitReader = async () => {
        if (!canSubmitReader.value) return
        isReaderSubmitting.value = true
        try {
            const name = readerNameValue.value.trim()
            if (readerModalMode.value === 'create') {
                const response = await buildingRepository.createReaderForDoor(readerDoorId.value, name)
                availableReaders.value = [response.data, ...availableReaders.value]
                readersTotal.value += 1
                generatedReaderToken.value = response.data.secret_token
            } else if (readerEditingId.value > 0) {
                await buildingRepository.updateReaderName(readerEditingId.value, name)
                if (selectedDoorReader.value?.rfid_reader_id === readerEditingId.value) {
                    selectedDoorReader.value = { ...selectedDoorReader.value, name }
                }
                availableReaders.value = availableReaders.value.map((item) =>
                    item.rfid_reader_id === readerEditingId.value ? { ...item, name } : item
                )
            }
            isReaderModalOpen.value = false
        } finally {
            isReaderSubmitting.value = false
        }
    }

    const copyGeneratedReaderToken = async () => {
        if (!generatedReaderToken.value) return
        await navigator.clipboard.writeText(generatedReaderToken.value)
        readerTokenCopySuccessMessage.value = ''
        window.setTimeout(() => {
            readerTokenCopySuccessMessage.value = params.copySuccessMessage.value
        }, 0)
    }

    return {
        doorToDelete,
        isDeletingDoor,
        readerDoorId,
        selectedDoorReader,
        availableReaders,
        readersSearch,
        readersOffset,
        readersLimit,
        readersTotal,
        isLoadingReaders,
        generatedReaderToken,
        isReaderModalOpen,
        readerModalMode,
        readerNameValue,
        isReaderSubmitting,
        readerToDelete,
        isDeletingReader,
        readerToRegenerate,
        isRegeneratingReaderToken,
        readerTokenCopySuccessMessage,
        canSubmitReader,
        addDoor,
        openDeleteDoorModal,
        closeDeleteDoorModal,
        confirmDeleteDoor,
        fetchDoorReaders,
        openDoorReaderModal,
        closeDoorReaderModal,
        assignReaderToDoor,
        unassignReaderFromDoor,
        openRegenerateReaderTokenModal,
        closeRegenerateReaderTokenModal,
        confirmRegenerateReaderToken,
        openDeleteReaderModal,
        closeDeleteReaderModal,
        confirmDeleteReader,
        openCreateReaderModal,
        openEditReaderModal,
        closeReaderModal,
        submitReader,
        copyGeneratedReaderToken
    }
}
