import { ref } from 'vue'
import { BUILDING_MAP_VIEWPORT_CONSTANTS } from '@/modules/building/constants/building-map-viewport.constants'
import { buildingRepository } from '@/modules/building/repositories/building.repository'
import type { DoorMapItem } from '@/modules/building/interfaces/door-map-item.interface'
import type { ViewportPageParams } from '@/modules/building/interfaces/viewport-bounds.interface'
import type { ZoneMapItem } from '@/modules/building/interfaces/zone-map-item.interface'

export const createBuildingViewMapState = (params: {
    selectedFloorId: { value: number }
    viewport: { value: { x: number; y: number; width: number; height: number } }
    zones: { value: ZoneMapItem[] }
    transitionValidationZones: { value: ZoneMapItem[] }
    transitionValidationDoors: { value: DoorMapItem[] }
    deletableZoneIds: { value: number[] }
    deletableDoorIds: { value: number[] }
    doors: { value: DoorMapItem[] }
}) => {
    const isLoadingMap = ref(false)

    let mapRequestId = 0
    let loadedFloorId = 0
    let activeFloorId = 0
    let isMapRequestInFlight = false
    let pendingMapSync = false

    const viewportCursorByKey = new Map<string, number | null>()

    const clearMapState = () => {
        params.zones.value = []
        params.doors.value = []
        params.transitionValidationZones.value = []
        params.transitionValidationDoors.value = []
        params.deletableZoneIds.value = []
        params.deletableDoorIds.value = []
        viewportCursorByKey.clear()
    }

    const getViewportKey = (viewport: ViewportPageParams) => [
        Math.floor(viewport.x),
        Math.floor(viewport.y),
        Math.ceil(viewport.width),
        Math.ceil(viewport.height)
    ].join(':')

    const fetchMap = async (options: { silent?: boolean; force?: boolean } = {}) => {
        const floorId = params.selectedFloorId.value

        if (floorId === 0) {
            mapRequestId += 1
            loadedFloorId = 0
            activeFloorId = 0
            clearMapState()
            return
        }

        const isFloorChanged = activeFloorId !== floorId

        if (isFloorChanged) {
            activeFloorId = floorId
            loadedFloorId = 0
            mapRequestId += 1
            clearMapState()
        }

        if (isMapRequestInFlight) {
            pendingMapSync = true
            return
        }

        isMapRequestInFlight = true
        const requestId = ++mapRequestId

        try {
            const isInitialFloorMapLoad = loadedFloorId !== floorId
            const shouldShowLoading =
                (!options.silent && params.zones.value.length === 0) ||
                isInitialFloorMapLoad

            if (shouldShowLoading) isLoadingMap.value = true

            const seedViewport = isInitialFloorMapLoad
                ? (await buildingRepository.getFloorMapSeed(floorId)).data.viewport
                : null

            if (requestId !== mapRequestId || floorId !== params.selectedFloorId.value) return

            const mapViewport: ViewportPageParams = seedViewport
                ? { ...seedViewport, limit: BUILDING_MAP_VIEWPORT_CONSTANTS.PAGE_LIMIT }
                : {
                    ...params.viewport.value,
                    limit: BUILDING_MAP_VIEWPORT_CONSTANTS.PAGE_LIMIT
                }

            const viewportKey = getViewportKey(mapViewport)

            const nextViewportCursor = isInitialFloorMapLoad || options.force
                ? undefined
                : viewportCursorByKey.get(viewportKey)

            if (!isInitialFloorMapLoad && !options.force && nextViewportCursor === null) return

            if (nextViewportCursor !== undefined && nextViewportCursor !== null) {
                mapViewport.cursor = nextViewportCursor
            }

            if (seedViewport) params.viewport.value = seedViewport

            const mapResponse = await buildingRepository.getFloorMap(floorId, mapViewport)

            if (requestId !== mapRequestId || floorId !== params.selectedFloorId.value) return

            if (isInitialFloorMapLoad) viewportCursorByKey.clear()

            applyMapResponse(mapResponse.data, isInitialFloorMapLoad)

            viewportCursorByKey.set(viewportKey, mapResponse.data.map_meta.next_cursor)
            loadedFloorId = floorId

            await fetchRemainingPages({
                requestId,
                floorId,
                viewportKey,
                viewport: mapViewport,
                cursor: mapResponse.data.map_meta.next_cursor,
                isLod: mapResponse.data.map_meta.is_lod
            })
        } catch {
            if (requestId === mapRequestId && isFloorChanged) {
                clearMapState()
            }
        } finally {
            isMapRequestInFlight = false

            if (requestId === mapRequestId) {
                isLoadingMap.value = false
            }

            if (pendingMapSync) {
                pendingMapSync = false
                void fetchMap({ silent: true })
            }
        }
    }

    const applyMapResponse = (
        response: {
            zones: ZoneMapItem[]
            doors: DoorMapItem[]
            transition_validation_zones: ZoneMapItem[]
            transition_validation_doors: DoorMapItem[]
            deletable_zone_ids: number[]
            deletable_door_ids: number[]
            zone_clusters?: unknown[]
        },
        shouldReplace: boolean
    ) => {
        params.zones.value = mergeZonesForViewport(
            params.zones.value,
            response.zones,
            shouldReplace
        )

        params.transitionValidationZones.value = shouldReplace
            ? response.transition_validation_zones || response.zones
            : mergeZonesForViewport(
                params.transitionValidationZones.value,
                response.transition_validation_zones || response.zones,
                false
            )

        params.transitionValidationDoors.value = mergeDoors(
            params.transitionValidationDoors.value,
            response.transition_validation_doors || response.doors,
            shouldReplace
        )

        params.deletableZoneIds.value = mergeIds(
            params.deletableZoneIds.value,
            response.deletable_zone_ids || [],
            shouldReplace
        )

        params.deletableDoorIds.value = mergeIds(
            params.deletableDoorIds.value,
            response.deletable_door_ids || [],
            shouldReplace
        )

        params.doors.value = mergeDoors(params.doors.value, response.doors, shouldReplace)
    }

    const fetchRemainingPages = async (paramsToLoad: {
        requestId: number
        floorId: number
        viewportKey: string
        viewport: ViewportPageParams
        cursor: number | null
        isLod: boolean
    }) => {
        if (paramsToLoad.isLod) return

        let cursor = paramsToLoad.cursor
        let pagesLoaded = 1

        while (
            cursor !== null &&
            pagesLoaded < BUILDING_MAP_VIEWPORT_CONSTANTS.MAX_AUTO_PAGES &&
            paramsToLoad.requestId === mapRequestId &&
            paramsToLoad.floorId === params.selectedFloorId.value
            ) {
            const response = await buildingRepository.getFloorMap(paramsToLoad.floorId, {
                ...paramsToLoad.viewport,
                cursor,
                limit: BUILDING_MAP_VIEWPORT_CONSTANTS.PAGE_LIMIT
            })

            if (
                paramsToLoad.requestId !== mapRequestId ||
                paramsToLoad.floorId !== params.selectedFloorId.value
            ) return

            applyMapResponse(response.data, false)

            cursor = response.data.map_meta.next_cursor
            viewportCursorByKey.set(paramsToLoad.viewportKey, cursor)
            pagesLoaded += 1
        }
    }

    const mergeZonesForViewport = (
        currentZones: ZoneMapItem[],
        responseZones: ZoneMapItem[],
        shouldReplace: boolean
    ) => {
        if (shouldReplace) return responseZones

        const currentZonesById = new Map(currentZones.map((zone) => [zone.zone_id, zone]))

        for (const zone of responseZones) {
            currentZonesById.set(zone.zone_id, zone)
        }

        return [...currentZonesById.values()]
    }

    const mergeDoors = (
        currentDoors: DoorMapItem[],
        responseDoors: DoorMapItem[],
        shouldReplace: boolean
    ) => {
        if (shouldReplace) return responseDoors

        const currentDoorsById = new Map(currentDoors.map((door) => [door.door_id, door]))

        for (const door of responseDoors) {
            currentDoorsById.set(door.door_id, door)
        }

        return [...currentDoorsById.values()]
    }

    const mergeIds = (
        currentIds: number[],
        responseIds: number[],
        shouldReplace: boolean
    ) => shouldReplace
        ? responseIds
        : [...new Set([...currentIds, ...responseIds])]

    const scheduleMapSync = () => {
        void fetchMap({ silent: true, force: true })
    }

    const updateViewport = (nextViewport: { x: number; y: number; width: number; height: number }) => {
        if (
            params.viewport.value.x === nextViewport.x &&
            params.viewport.value.y === nextViewport.y &&
            params.viewport.value.width === nextViewport.width &&
            params.viewport.value.height === nextViewport.height
        ) return

        params.viewport.value = nextViewport
    }

    return {
        isLoadingMap,
        fetchMap,
        scheduleMapSync,
        updateViewport
    }
}
