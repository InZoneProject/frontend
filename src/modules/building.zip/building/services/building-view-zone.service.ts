import { computed, ref } from 'vue'
import { isAxiosError } from 'axios'
import { buildingRepository } from '@/modules/building/repositories/building.repository'
import type { BuildingMapAddZonePayload } from '@/modules/building/interfaces/building-map-add-zone-payload.interface'
import type { DoorMapItem } from '@/modules/building/interfaces/door-map-item.interface'
import type { ZoneMapItem } from '@/modules/building/interfaces/zone-map-item.interface'

export const createBuildingViewZoneState = (params: {
    buildingId: { value: number }
    selectedFloorId: { value: number }
    zones: { value: ZoneMapItem[] }
    transitionValidationZones: { value: ZoneMapItem[] }
    doors: { value: DoorMapItem[] }
    transitionValidationDoors: { value: DoorMapItem[] }
    deletableZoneIds: { value: number[] }
    deletableDoorIds: { value: number[] }
    zoneCreateDefaultErrorMessage: { value: string }
    zoneOverlapErrorMessage: { value: string }
    zoneNoIntersectionErrorMessage: { value: string }
    zoneDoorSpaceErrorMessage: { value: string }
    scheduleMapSync?: () => void
}) => {
    const pendingZonePayload = ref<BuildingMapAddZonePayload | null>(null)
    const isZoneCreateModalOpen = ref(false)
    const zoneTitleValue = ref('')
    const zoneIsTransitionBetweenFloors = ref(false)
    const zoneCanCreateTransition = ref(false)
    const zoneCreateErrorMessage = ref('')
    const isZoneSubmitting = ref(false)
    const isEditingZone = ref(false)
    const accessRulesZoneId = ref(0)
    const accessRulesZoneTitle = ref('')
    const zoneToDeleteId = ref(0)
    const isDeletingZone = ref(false)

    const runAfterInteraction = (callback: () => void) => {
        globalThis.setTimeout(() => {
            const idleCallback = globalThis.requestIdleCallback as
                | ((callback: IdleRequestCallback, options?: IdleRequestOptions) => number)
                | undefined

            if (idleCallback) {
                idleCallback(() => callback(), { timeout: 700 })
                return
            }

            globalThis.setTimeout(callback, 0)
        }, 120)
    }

    const canSubmitZone = computed(() => {
        if (!pendingZonePayload.value) return false
        if (zoneTitleValue.value.trim().length === 0) return false
        return !zoneIsTransitionBetweenFloors.value || zoneCanCreateTransition.value
    })

    const openZoneAccessRulesModal = (zoneId: number) => {
        accessRulesZoneId.value = zoneId
        accessRulesZoneTitle.value = params.zones.value.find((zone) => zone.zone_id === zoneId)?.title || ''
    }

    const closeZoneAccessRulesModal = () => {
        accessRulesZoneId.value = 0
        accessRulesZoneTitle.value = ''
    }

    const commitZoneGeometry = async (
        zoneId: number,
        payload: { width: number; height: number; x_coordinate: number; y_coordinate: number },
        previewedZones?: Array<{ zone_id: number; x_coordinate: number; y_coordinate: number; width: number; height: number }>
    ) => {
        void buildingRepository.updateZoneGeometry(zoneId, payload)

        runAfterInteraction(() => {
            if (previewedZones?.length) {
                const previewedZonesById = new Map(previewedZones.map((zone) => [zone.zone_id, zone]))

                params.zones.value = params.zones.value.map((zone) => ({
                    ...zone,
                    ...(previewedZonesById.get(zone.zone_id) || {})
                }))

                params.transitionValidationZones.value = params.transitionValidationZones.value.map((zone) => ({
                    ...zone,
                    ...(previewedZonesById.get(zone.zone_id) || {})
                }))

                return
            }

            params.zones.value = params.zones.value.map((zone) =>
                zone.zone_id === zoneId ? { ...zone, ...payload } : zone
            )

            params.transitionValidationZones.value = params.transitionValidationZones.value.map((zone) =>
                zone.zone_id === zoneId ? { ...zone, ...payload } : zone
            )
        })
    }

    const shiftZone = async (zoneId: number, payload: { x_coordinate: number; y_coordinate: number }) => {
        void buildingRepository.shiftBuildingZones(zoneId, payload)

        runAfterInteraction(() => {
            const original = params.zones.value.find((zone) => zone.zone_id === zoneId)
            if (!original) return

            const deltaX = payload.x_coordinate - original.x_coordinate
            const deltaY = payload.y_coordinate - original.y_coordinate

            params.zones.value = params.zones.value.map((zone) => ({
                ...zone,
                x_coordinate: zone.x_coordinate + deltaX,
                y_coordinate: zone.y_coordinate + deltaY
            }))

            params.transitionValidationZones.value = params.transitionValidationZones.value.map((zone) => ({
                ...zone,
                x_coordinate: zone.x_coordinate + deltaX,
                y_coordinate: zone.y_coordinate + deltaY
            }))
        })
    }

    const updateZoneTitle = async (zoneId: number, title: string) => {
        isEditingZone.value = true
        const previousZones = params.zones.value
        params.zones.value = params.zones.value.map((zone) => zone.zone_id === zoneId ? { ...zone, title } : zone)
        try {
            await buildingRepository.updateZoneTitle(zoneId, title)
        } catch (error) {
            params.zones.value = previousZones
            throw error
        } finally {
            isEditingZone.value = false
        }
    }

    const updateZonePhoto = async (zoneId: number, file: File) => {
        isEditingZone.value = true
        try {
            const response = await buildingRepository.updateZonePhoto(zoneId, file)
            params.zones.value = params.zones.value.map((zone) => zone.zone_id === zoneId
                ? { ...zone, photo: response.data.photo }
                : zone)
        } finally {
            isEditingZone.value = false
        }
    }

    const addZone = (payload: BuildingMapAddZonePayload) => {
        if (params.selectedFloorId.value === 0) return

        pendingZonePayload.value = payload
        zoneTitleValue.value = (payload.title || payload.regular_payload?.title || payload.transition_payload?.title || '').trim()
        zoneCanCreateTransition.value = payload.can_create_transition && !!payload.transition_payload
        zoneIsTransitionBetweenFloors.value = false
        zoneCreateErrorMessage.value = ''
        isZoneCreateModalOpen.value = true
    }

    const closeZoneCreateModal = () => {
        if (isZoneSubmitting.value) return
        isZoneCreateModalOpen.value = false
        pendingZonePayload.value = null
        zoneTitleValue.value = ''
        zoneIsTransitionBetweenFloors.value = false
        zoneCanCreateTransition.value = false
        zoneCreateErrorMessage.value = ''
    }

    const submitZone = async () => {
        if (!canSubmitZone.value || !pendingZonePayload.value) return
        isZoneSubmitting.value = true
        const payload = pendingZonePayload.value

        const selectedPayload =
            zoneIsTransitionBetweenFloors.value && payload.transition_payload
                ? payload.transition_payload
                : payload.regular_payload || payload

        try {
            const zonePayload: {
                title: string
                width: number
                height: number
                x_coordinate: number
                y_coordinate: number
                building_id: number
                is_transition_between_floors: boolean
                zone_from_id: number
                floor_id?: number
            } = {
                title: zoneTitleValue.value.trim(),
                width: selectedPayload.width,
                height: selectedPayload.height,
                x_coordinate: selectedPayload.x_coordinate,
                y_coordinate: selectedPayload.y_coordinate,
                building_id: params.buildingId.value,
                is_transition_between_floors: zoneIsTransitionBetweenFloors.value,
                zone_from_id: selectedPayload.zone_from_id
            }
            zonePayload.floor_id = params.selectedFloorId.value
            const response = await buildingRepository.createZone(zonePayload)
            const createdZone = response.data as ZoneMapItem
            if (createdZone && typeof createdZone.zone_id === 'number') {
                const normalizedZone: ZoneMapItem = {
                    ...createdZone,
                    title: createdZone.title || zonePayload.title,
                    width: createdZone.width ?? zonePayload.width,
                    height: createdZone.height ?? zonePayload.height,
                    x_coordinate: createdZone.x_coordinate ?? zonePayload.x_coordinate,
                    y_coordinate: createdZone.y_coordinate ?? zonePayload.y_coordinate,
                    photo: createdZone.photo ?? null,
                    is_transition_between_floors: createdZone.is_transition_between_floors ?? zonePayload.is_transition_between_floors,
                    floor_id: createdZone.is_transition_between_floors
                        ? createdZone.floor_id ?? null
                        : createdZone.floor_id ?? params.selectedFloorId.value
                }

                const upsertZone = (zoneList: ZoneMapItem[]) => [
                    ...zoneList.filter((zone) => zone.zone_id !== normalizedZone.zone_id),
                    normalizedZone
                ]

                params.zones.value = upsertZone(params.zones.value)
                params.transitionValidationZones.value = upsertZone(params.transitionValidationZones.value)

                if (!params.deletableZoneIds.value.includes(createdZone.zone_id)) {
                    params.deletableZoneIds.value = [...params.deletableZoneIds.value, createdZone.zone_id]
                }

                params.scheduleMapSync?.()
            }

            isZoneSubmitting.value = false
            closeZoneCreateModal()
        } catch (error) {
            if (isAxiosError(error) && error.response?.status === 400) {
                const responseMessage = error.response.data?.message
                const message = Array.isArray(responseMessage)
                    ? responseMessage.join(', ')
                    : String(responseMessage || '')
                zoneCreateErrorMessage.value = resolveZoneCreateErrorMessage(message)
                if (zoneIsTransitionBetweenFloors.value) {
                    zoneIsTransitionBetweenFloors.value = false
                    zoneCanCreateTransition.value = false
                }
                return
            }
            throw error
        } finally {
            isZoneSubmitting.value = false
        }
    }

    const resolveZoneCreateErrorMessage = (message: string) => {
        if (message.includes('overlap') || message.includes('overlaps')) {
            return params.zoneOverlapErrorMessage.value
        }

        if (message.includes('touch') || message.includes('intersect')) {
            return params.zoneNoIntersectionErrorMessage.value
        }

        if (message.includes('entrance door')) {
            return params.zoneOverlapErrorMessage.value
        }

        if (message.includes('door')) {
            return params.zoneDoorSpaceErrorMessage.value
        }

        return message || params.zoneCreateDefaultErrorMessage.value
    }

    const openDeleteZoneModal = (zoneId: number) => {
        zoneToDeleteId.value = zoneId
    }

    const closeDeleteZoneModal = () => {
        if (isDeletingZone.value) return
        zoneToDeleteId.value = 0
    }

    const confirmDeleteZone = async () => {
        if (zoneToDeleteId.value === 0) return
        isDeletingZone.value = true
        try {
            await buildingRepository.deleteZone(zoneToDeleteId.value)
            const deletedZoneId = zoneToDeleteId.value
            zoneToDeleteId.value = 0
            params.zones.value = params.zones.value.filter((zone) => zone.zone_id !== deletedZoneId)
            params.transitionValidationZones.value = params.transitionValidationZones.value.filter((zone) => zone.zone_id !== deletedZoneId)
            params.deletableZoneIds.value = params.deletableZoneIds.value.filter((zoneId) => zoneId !== deletedZoneId)

            const isConnectedDoor = (door: DoorMapItem) =>
                door.zone_to_id === deletedZoneId || door.zone_from_id === deletedZoneId
            const deletedDoorIds = new Set(
                params.doors.value.filter(isConnectedDoor).map((door) => door.door_id)
            )
            params.doors.value = params.doors.value.filter((door) => !isConnectedDoor(door))
            params.transitionValidationDoors.value = params.transitionValidationDoors.value.filter((door) => !isConnectedDoor(door))
            if (deletedDoorIds.size > 0) {
                params.deletableDoorIds.value = params.deletableDoorIds.value.filter((doorId) => !deletedDoorIds.has(doorId))
            }

            params.scheduleMapSync?.()
        } finally {
            isDeletingZone.value = false
        }
    }

    return {
        pendingZonePayload,
        isZoneCreateModalOpen,
        zoneTitleValue,
        zoneIsTransitionBetweenFloors,
        zoneCanCreateTransition,
        zoneCreateErrorMessage,
        isZoneSubmitting,
        isEditingZone,
        accessRulesZoneId,
        accessRulesZoneTitle,
        zoneToDeleteId,
        isDeletingZone,
        canSubmitZone,
        openZoneAccessRulesModal,
        closeZoneAccessRulesModal,
        commitZoneGeometry,
        shiftZone,
        updateZoneTitle,
        updateZonePhoto,
        addZone,
        closeZoneCreateModal,
        submitZone,
        openDeleteZoneModal,
        closeDeleteZoneModal,
        confirmDeleteZone
    }
}
